package StepDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepdefination {

	/*@Given("I am able to login into application")
	public void i_am_able_to_login_into_application() {
	    System.out.println("......given.........");
	}

	@When("USer logs into the Application")
	public void u_ser_logs_into_the_application() {
	   System.out.println("..........when...........");}

	@Then("user should be able to see the search box.")
	public void user_should_be_able_to_see_the_search_box() {
	    System.out.println("then..............");
	}*/
	
	
}

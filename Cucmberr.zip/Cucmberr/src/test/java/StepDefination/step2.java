package StepDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class step2 {
	
	@Given("user is on the Landing Page with Valid Credentials")
	public void user_is_on_the_landing_page_with_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
	}
	@When("user logs ionto the application with {string} and Password {string}")
	public void user_logs_ionto_the_application_with_and_password(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(string);
	    System.out.println(string2);
	}
	@Then("user is able to login into the appliction")
	public void user_is_able_to_login_into_the_appliction() {
	    // Write code here that turns the phrase above into concrete actions
	}
	@Then("Account details are displayed when {string}")
	public void account_details_are_displayed_when(String string) {
	    
	}



	}










